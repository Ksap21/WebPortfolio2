import tkinter as tk
from tkinter import messagebox
import random
import string
import hashlib
import sys
import os
from tkinter import ttk
import subprocess


# Restart app and logout
def restart_app():
    script_path = os.path.abspath(__file__)
    subprocess.Popen([sys.executable, script_path])
    root.destroy()



retrieve_password_label = None  
pinCode="1two3"
# Function to generate a password
def generate_password(length, exclude_chars):
    if length > 30:
        messagebox.showerror("Error", "Password length cannot exceed 30 characters!")
        return ""

    all_characters = string.ascii_letters + string.digits + string.punctuation
    available_characters = ''.join([char for char in all_characters if char not in exclude_chars])

    if not available_characters:
        messagebox.showerror("Error", "No valid characters available for password generation!")
        return ""

    password = ''.join(random.choice(available_characters) for _ in range(length))
    return password

# Function to save password
def save_to_file(password, title):
    if not title.strip():
        messagebox.showerror("Error", "Title is required!")
        return

    # Check if the title already exists in the file when creating a new password
    if check_duplicate_title(title):
        messagebox.showerror("Error", "Title already exists in the file!")
        return

    try:
        with open(os.path.expanduser("~/Credentials.txt"), "a") as file:
            file.write(f"Title: {title}\nPassword: {password}\n\n---\n")
            messagebox.showinfo("Success", "Password saved successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save password: {e}")


# Function to retrieve a password
def retrieve_password(title, pin):
    if not title.strip():
        messagebox.showerror("Error", "Title is required!")
        return
    if pin != pinCode:
        messagebox.showerror("Error", "Incorrect PIN!")
        return

    try:
        with open(os.path.expanduser("~/Credentials.txt"), "r") as file:
            data = file.readlines()

        found, stored_password = False, None

        for i in range(len(data)):
            if f"Title: {title}" in data[i]:
                found = True
                stored_password = data[i + 1].replace("Password: ", "").strip()
                break

        if found and stored_password:
            retrieve_password_label.config(text=f"Retrieved Password: {stored_password}")
        else:
            messagebox.showerror("Error", "No matching password found!")

    except FileNotFoundError:
        messagebox.showerror("Error", "Credentials file not found!")


# Function to copy a retrieved a password into clipboard

def copy_retrieved_password():
    global retrieve_password_label
    if retrieve_password_label:
        password = retrieve_password_label.cget("text").replace("Retrieved Password: ", "")
        if password.strip():
            root.clipboard_clear()
            root.clipboard_append(password)
            root.update()
            messagebox.showinfo("Copied", "Password copied to clipboard!")
        else:
            messagebox.showerror("Error", "No password to copy.")


# Function to update a password
def update_password(title, pin, new_password):
    if not title.strip():
        messagebox.showerror("Error", "Title is required!")
        return
    if pin != pinCode:
        messagebox.showerror("Error", "Incorrect PIN!")
        return
    if not new_password.strip():
        messagebox.showerror("Error", "New password cannot be empty!")
        return

    if not check_duplicate_title(title):
        messagebox.showerror("Error", "No matching password found to update!")
        return

    try:
        with open(os.path.expanduser("~/Credentials.txt"), "r") as file:
            data = file.readlines()

        found = False
        for i in range(len(data)):
            if f"Title: {title}" in data[i]:
                found = True
                data[i + 1] = f"Password: {new_password}\n"
                break

        if found:
            with open(os.path.expanduser("~/Credentials.txt"), "w") as file:
                file.writelines(data)
            messagebox.showinfo("Success", "Password updated successfully!")
        else:
            messagebox.showerror("Error", "No matching password found!")

    except FileNotFoundError:
        messagebox.showerror("Error", "Credentials file not found!")


# Function to check for duplicate title already exits in file
def check_duplicate_title(title):
    try:
        with open(os.path.expanduser("~/Credentials.txt"), "r") as file:
            data = file.readlines()

        for i in range(len(data)):
            if f"Title: {title}" in data[i]:
                return True
        return False

    except FileNotFoundError:
        return False

# Function to delete entry
def delete_password(title, pin):
    if not title.strip():
        messagebox.showerror("Error", "Title is required!")
        return
    if pin != pinCode:
        messagebox.showerror("Error", "Incorrect PIN!")
        return

    try:
        with open(os.path.expanduser("~/Credentials.txt"), "r") as file:
            data = file.readlines()

        new_data = []
        skip = False
        found = False

        for line in data:
            if line.startswith(f"Title: {title}"):
                skip = True
                found = True
                continue
            if skip and line.startswith("Password:"):
                continue
            if skip and line.strip() == "---":
                skip = False
                continue
            if not skip:
                new_data.append(line)

        if found:
            with open(os.path.expanduser("~/Credentials.txt"), "w") as file:
                file.writelines(new_data)
            messagebox.showinfo("Success", f"Password entry for '{title}' deleted.")
        else:
            messagebox.showerror("Error", "No matching title found.")

    except FileNotFoundError:
        messagebox.showerror("Error", "Credentials file not found!")


# Function to create and save hashed password after user registers a account into respective file
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Funstion to check for username and Password
def check_login(username, password):
    username = username.strip()
    password = password.strip()
    try:
        with open(os.path.expanduser("~/users.txt"), "r") as file:
            for line in file:
                stored_user, stored_hash = line.strip().split(":")
                if stored_user == username and stored_hash == hash_password(password):
                    return True
        return False
    except FileNotFoundError:
        return False

# Funstion to register an account
def register_user(username, password):
    username = username.strip()
    password = password.strip()
    if not username or not password:
        messagebox.showerror("Error", "Username and password cannot be empty!")
        return

    try:
        with open(os.path.expanduser("~/users.txt"), "r") as file:
            for line in file:
                if username == line.strip().split(":")[0]:
                    messagebox.showerror("Error", "Username already exists!")
                    return
    except FileNotFoundError:
        pass

    with open(os.path.expanduser("~/users.txt"), "a") as file:
        file.write(f"{username}:{hash_password(password)}\n")
    messagebox.showinfo("Success", "User registered successfully!")


# GUI Functions
def show_create_screen():
    choice_frame.pack_forget()
    create_frame.pack(pady=20)

def show_retrieve_screen():
    choice_frame.pack_forget()
    retrieve_frame.pack(pady=20)

def show_update_screen():
    choice_frame.pack_forget()
    update_frame.pack(pady=20)

def go_back():
    create_frame.pack_forget()
    retrieve_frame.pack_forget()
    update_frame.pack_forget()
    choice_frame.pack(pady=20)
    delete_frame.pack_forget()

def show_delete_screen():
    choice_frame.pack_forget()
    delete_frame.pack(pady=20)


# Funstion to generate Password

def on_generate_button_click():
    try:
        length = int(length_entry.get())
        exclude_chars = exclude_entry.get()
        title = title_entry.get().strip()

        if not title:
            messagebox.showerror("Error", "Title is required!")
            return

        # Check if title already exists before generating password
        if check_duplicate_title(title):
            messagebox.showerror("Error", "Title already exists in the file!")
            return

        password = generate_password(length, exclude_chars)

        if password:
            password_label.config(text=f"Generated Password: {password}")
            save_to_file(password, title)
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number for the password length.")



def on_retrieve_button_click():
    title = retrieve_title_entry.get().strip()
    pin = retrieve_pin_entry.get()
    retrieve_password(title, pin)


def on_update_button_click():
    update_password(update_title_entry.get().strip(), update_pin_entry.get(), update_new_password_entry.get())

# Setup GUI
root = tk.Tk()
root.title("Password Manager")
root.geometry("600x500")
root.configure(bg="#2C2F33")


style = ttk.Style()
style.theme_use("default")

style.configure("Custom.TButton",
    font=("Arial", 12, "bold"),
    foreground="white",
    background="#4B4B4B",
    padding=10,
    width=20,
    borderwidth=0
)

style.map("Custom.TButton",
    background=[("active", "#6C6C6C"), ("pressed", "#6C6C6C")],
    foreground=[("disabled", "gray")]
)

entry_style = {
    "font": ("Arial", 12),
    "width": 30,
    "bd": 3,
    "relief": "ridge"
}

# Login Style
# Login Frame
login_frame = tk.Frame(root, bg="#2C2F33")

tk.Label(login_frame, text="Login to Password Manager", font=("Arial", 16, "bold"), fg="white", bg="#2C2F33").pack(pady=10)

tk.Label(login_frame, text="Username", fg="white", bg="#2C2F33", font=("Arial", 12)).pack()
username_entry = tk.Entry(login_frame, **entry_style)
username_entry.pack()

tk.Label(login_frame, text="Password", fg="white", bg="#2C2F33", font=("Arial", 12)).pack()
password_entry = tk.Entry(login_frame, show="*", **entry_style)
password_entry.pack()

# Buttons side by side
button_row = tk.Frame(login_frame, bg="#2C2F33")
button_row.pack(pady=15)

def login():
    user = username_entry.get().strip()
    pwd = password_entry.get()
    if check_login(user, pwd):
        login_frame.pack_forget()

        # Now set up and show the main menu
        tk.Label(choice_frame, text="Password Manager", font=("Arial", 18, "bold"), fg="white", bg="#2C2F33").pack(pady=10)

        # <------------------------------------Ran into problems like GUI not loading using tk so replaced with ttk---------------------------------------->
        # tk.Button(choice_frame, text="Create Password", command=show_create_screen, **button_style).pack(pady=10)
        ttk.Button(choice_frame, text="Create Password", command=show_create_screen, style="Custom.TButton").pack(pady=10)

        # tk.Button(choice_frame, text="Retrieve Password", command=show_retrieve_screen, **button_style).pack(pady=10)
        ttk.Button(choice_frame, text="Retrieve Password", command=show_retrieve_screen, style="Custom.TButton").pack(pady=10)

        # tk.Button(choice_frame, text="Update Password", command=show_update_screen, **button_style).pack(pady=10)
        ttk.Button(choice_frame, text="Update Password", command=show_update_screen, style="Custom.TButton").pack(pady=10)

        # tk.Button(choice_frame, text="Delete Password", command=show_delete_screen, **button_style).pack(pady=10)
        ttk.Button(choice_frame, text="Delete Password", command=show_delete_screen, style="Custom.TButton").pack(pady=10)

        # tk.Button(choice_frame, text="Restart App", command=restart_app, **button_style).pack(pady=10)
        ttk.Button(choice_frame, text="Restart App", command=restart_app, style="Custom.TButton").pack(pady=10)

        choice_frame.pack(pady=20)
    else:
        messagebox.showerror("Login Failed", "Incorrect username or password.")

def register():
    user = username_entry.get().strip()
    pwd = password_entry.get()
    register_user(user, pwd)

ttk.Button(button_row, text="Login", command=login, style="Custom.TButton").pack(side="left", padx=10)
ttk.Button(button_row, text="Register", command=register, style="Custom.TButton").pack(side="right", padx=10)

# Main choice frame
choice_frame = tk.Frame(root, bg="#2C2F33")
login_frame.pack(pady=40)

try:
    login_frame.pack(pady=40)
except Exception as e:
    print("Error when packing login_frame:", e)


# Create Password Frame
create_frame = tk.Frame(root, bg="#2C2F33")

tk.Label(create_frame, text="Title (Required):", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
title_entry = tk.Entry(create_frame, **entry_style)
title_entry.pack()

tk.Label(create_frame, text="Password Length:", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
length_entry = tk.Entry(create_frame, **entry_style)
length_entry.pack()

tk.Label(create_frame, text="Exclude Characters:", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
exclude_entry = tk.Entry(create_frame, **entry_style)
exclude_entry.pack()

ttk.Button(create_frame, text="Generate Password", command=on_generate_button_click, style="Custom.TButton").pack(pady=10)
ttk.Button(create_frame, text="Go Back", command=go_back, style="Custom.TButton").pack(pady=5)

password_label = tk.Label(create_frame, text="Generated Password: ", font=("Arial", 12), fg="white", bg="#2C2F33")
password_label.pack()

# Retrieve Password Frame
retrieve_frame = tk.Frame(root, bg="#2C2F33")

tk.Label(retrieve_frame, text="Title (Required):", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
retrieve_title_entry = tk.Entry(retrieve_frame, **entry_style)
retrieve_title_entry.pack()

tk.Label(retrieve_frame, text="Enter PIN:", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
retrieve_pin_entry = tk.Entry(retrieve_frame, show="*", **entry_style)
retrieve_pin_entry.pack()

ttk.Button(retrieve_frame, text="Retrieve Password", command=on_retrieve_button_click, style="Custom.TButton").pack(pady=10)

retrieve_password_label = tk.Label(retrieve_frame, text="", font=("Arial", 12), fg="white", bg="#2C2F33")
retrieve_password_label.pack()


ttk.Button(retrieve_frame, text="Copy Password", command=copy_retrieved_password, style="Custom.TButton").pack(pady=5)
ttk.Button(retrieve_frame, text="Go Back", command=go_back, style="Custom.TButton").pack(pady=5)



# Update Password Frame
update_frame = tk.Frame(root, bg="#2C2F33")

tk.Label(update_frame, text="Title (Required):", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
update_title_entry = tk.Entry(update_frame, **entry_style)
update_title_entry.pack()

tk.Label(update_frame, text="Enter PIN:", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
update_pin_entry = tk.Entry(update_frame, show="*", **entry_style)
update_pin_entry.pack()

tk.Label(update_frame, text="New Password (Required):", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
update_new_password_entry = tk.Entry(update_frame, **entry_style)
update_new_password_entry.pack()

ttk.Button(update_frame, text="Update Password", command=on_update_button_click, style="Custom.TButton").pack(pady=10)
ttk.Button(update_frame, text="Go Back", command=go_back, style="Custom.TButton").pack(pady=5)


# delete frame UI
delete_frame = tk.Frame(root, bg="#2C2F33")

tk.Label(delete_frame, text="Title (Required):", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
delete_title_entry = tk.Entry(delete_frame, **entry_style)
delete_title_entry.pack()

tk.Label(delete_frame, text="Enter PIN:", font=("Arial", 12), fg="white", bg="#2C2F33").pack()
delete_pin_entry = tk.Entry(delete_frame, show="*", **entry_style)
delete_pin_entry.pack()

ttk.Button(delete_frame, text="Delete Entry", command=lambda: delete_password(delete_title_entry.get().strip(), delete_pin_entry.get()), style="Custom.TButton").pack(pady=10)
ttk.Button(delete_frame, text="Go Back", command=go_back, style="Custom.TButton").pack(pady=5)

root.mainloop()
